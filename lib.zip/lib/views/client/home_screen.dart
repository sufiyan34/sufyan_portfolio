import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sufyan_portfolio/constant/app_colors.dart';
import 'package:sufyan_portfolio/constant/app_routes.dart';
import 'package:sufyan_portfolio/controllers/home_controller.dart';
import 'package:sufyan_portfolio/widgets/hero_section.dart';
import 'package:sufyan_portfolio/widgets/public_navbar.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(HomeController());

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: const PublicNavbar(activeRoute: AppRoutes.home),
      body: const SingleChildScrollView(
        child: Column(
          children: [
            HeroSection(),
            // TODO: next sections go here, one at a time —
            // Technology strip, About preview, Services, Projects,
            // Packages CTA, Testimonials, Contact, Footer.
          ],
        ),
      ),
    );
  }
}
