import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:sufyan_portfolio/constant/app_colors.dart';
import 'package:sufyan_portfolio/constant/app_routes.dart';
import 'package:sufyan_portfolio/constant/app_text_styles.dart';

/// One nav item shown in [PublicNavbar] and the mobile drawer.
class _NavItem {
  final String label;
  final String route;
  const _NavItem(this.label, this.route);
}

const List<_NavItem> _kNavItems = [
  _NavItem('Home', AppRoutes.home),
  _NavItem('About', AppRoutes.about),
  _NavItem('Services', AppRoutes.services),
  _NavItem('Skills', AppRoutes.skills),
  _NavItem('Projects', AppRoutes.projects),
  _NavItem('Packages', AppRoutes.packages),
  _NavItem('Hire Me', AppRoutes.hireUs),
  _NavItem('Contact', AppRoutes.contactUs),
];

/// Public site navigation bar — per PORTFOLIO_UI_DESIGN_SPEC.md section 9.
///
/// Page-colored background, 72-78px tall, MS monogram, nav row on desktop,
/// hamburger drawer on mobile/tablet. [activeRoute] draws the small
/// underline indicator on the matching item.
class PublicNavbar extends StatelessWidget implements PreferredSizeWidget {
  final String activeRoute;
  final VoidCallback? onLetsTalk;

  const PublicNavbar({
    super.key,
    this.activeRoute = AppRoutes.home,
    this.onLetsTalk,
  });

  @override
  Size get preferredSize => Size.fromHeight(76.h);

  bool _isDesktop(BuildContext context) =>
      MediaQuery.of(context).size.width >= 1200;

  @override
  Widget build(BuildContext context) {
    final isDesktop = _isDesktop(context);

    return Container(
      height: preferredSize.height,
      decoration: BoxDecoration(
        color: AppColors.background,
        border: Border(bottom: BorderSide(color: AppColors.border, width: 1)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: isDesktop ? 48.w : 20.w),
          child: Row(
            children: [
              const _BrandMark(),
              const Spacer(),
              if (isDesktop) ...[
                for (final item in _kNavItems)
                  _NavLink(
                    label: item.label,
                    route: item.route,
                    active: item.route == activeRoute,
                  ),
                SizedBox(width: 16.w),
                _LetsTalkButton(onTap: onLetsTalk),
              ] else
                _HamburgerButton(
                  activeRoute: activeRoute,
                  onLetsTalk: onLetsTalk,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// "MS" monogram brand mark — minimal, editorial, deep green silhouette.
class _BrandMark extends StatelessWidget {
  const _BrandMark();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 36.w,
          height: 36.w,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(10.r),
          ),
          child: Text(
            'MS',
            style: AppTextStyles.bodyMedium(color: AppColors.textOnPrimary)
                .copyWith(fontSize: 14.sp, letterSpacing: 0.5),
          ),
        ),
      ],
    );
  }
}

class _NavLink extends StatefulWidget {
  final String label;
  final String route;
  final bool active;

  const _NavLink({
    required this.label,
    required this.route,
    required this.active,
  });

  @override
  State<_NavLink> createState() => _NavLinkState();
}

class _NavLinkState extends State<_NavLink> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final highlighted = widget.active || _hovered;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: GestureDetector(
        onTap: () {
          if (!widget.active) Get.toNamed(widget.route);
        },
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 14.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.label,
                style: AppTextStyles.bodyMedium(
                  color: highlighted
                      ? AppColors.primary
                      : AppColors.textSecondary,
                ).copyWith(fontSize: 14.5.sp, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 4.h),
              AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: widget.active ? 16.w : 0,
                height: 2.h,
                decoration: BoxDecoration(
                  color: AppColors.accentGold,
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LetsTalkButton extends StatelessWidget {
  final VoidCallback? onTap;
  const _LetsTalkButton({this.onTap});

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 42.h,
          padding: EdgeInsets.symmetric(horizontal: 22.w),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            "Let's Talk",
            style: AppTextStyles.bodyMedium(color: AppColors.textOnPrimary)
                .copyWith(fontSize: 14.sp),
          ),
        ),
      ),
    );
  }
}

class _HamburgerButton extends StatelessWidget {
  final String activeRoute;
  final VoidCallback? onLetsTalk;
  const _HamburgerButton({required this.activeRoute, this.onLetsTalk});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.menu_rounded, color: AppColors.textPrimary, size: 26.sp),
      onPressed: () {
        showModalBottomSheet(
          context: context,
          backgroundColor: AppColors.background,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
          ),
          builder: (_) =>
              _MobileNavSheet(activeRoute: activeRoute, onLetsTalk: onLetsTalk),
        );
      },
    );
  }
}

class _MobileNavSheet extends StatelessWidget {
  final String activeRoute;
  final VoidCallback? onLetsTalk;
  const _MobileNavSheet({required this.activeRoute, this.onLetsTalk});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 20.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (final item in _kNavItems)
              ListTile(
                title: Text(
                  item.label,
                  style: AppTextStyles.bodyMedium(
                    color: item.route == activeRoute
                        ? AppColors.primary
                        : AppColors.textPrimary,
                  ),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                  if (item.route != activeRoute) Get.toNamed(item.route);
                },
              ),
            SizedBox(height: 12.h),
            _LetsTalkButton(
              onTap: () {
                Navigator.of(context).pop();
                onLetsTalk?.call();
              },
            ),
          ],
        ),
      ),
    );
  }
}
