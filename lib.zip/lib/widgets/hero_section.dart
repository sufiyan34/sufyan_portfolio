import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:sufyan_portfolio/constant/app_colors.dart';
import 'package:sufyan_portfolio/constant/app_text_styles.dart';
import 'package:sufyan_portfolio/controllers/home_controller.dart';
import 'package:sufyan_portfolio/models/home_content_model.dart';

/// Home page hero — per PORTFOLIO_UI_DESIGN_SPEC.md section 12.
///
/// Desktop: text column on the left, large portrait on the right, with a
/// stat row underneath. Tablet/mobile: stacked, portrait on top.
///
/// Copy, CTA labels/routes, the portrait image and the stat row all come
/// from [HomeController] (backed by the `homeContent` Firebase node) and
/// fall back to the original static copy until that data loads.
class HeroSection extends StatelessWidget {
  const HeroSection({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<HomeController>();
    final width = MediaQuery.of(context).size.width;
    final isDesktop = width >= 1200;
    final isTablet = width >= 768 && width < 1200;

    return Container(
      color: AppColors.background,
      child: Obx(() {
        final data = controller.content.value;
        final stats = controller.stats;

        return Padding(
          padding: EdgeInsets.symmetric(
            horizontal: isDesktop ? 48.w : 20.w,
            vertical: isDesktop ? 80.h : 48.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (isDesktop)
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      flex: 6,
                      child: _HeroText(isDesktop: true, data: data),
                    ),
                    SizedBox(width: 64.w),
                    Expanded(
                      flex: 5,
                      child: _HeroPortrait(imageUrl: data.heroImageUrl),
                    ),
                  ],
                )
              else ...[
                _HeroPortrait(imageUrl: data.heroImageUrl),
                SizedBox(height: isTablet ? 40.h : 32.h),
                _HeroText(isDesktop: false, data: data),
              ],
              SizedBox(height: isDesktop ? 64.h : 40.h),
              _HeroStatsRow(stats: stats),
            ],
          ),
        );
      }),
    );
  }
}

class _HeroText extends StatelessWidget {
  final bool isDesktop;
  final HomeContentModel data;
  const _HeroText({required this.isDesktop, required this.data});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: isDesktop
          ? CrossAxisAlignment.start
          : CrossAxisAlignment.center,
      children: [
        Text(
              data.eyebrow,
              textAlign: isDesktop ? TextAlign.left : TextAlign.center,
              style: AppTextStyles.h2(color: AppColors.textSecondary)
                  .copyWith(fontWeight: FontWeight.w600),
            )
            .animate()
            .fadeIn(duration: const Duration(milliseconds: 500))
            .slideY(
              begin: 0.2,
              end: 0,
              duration: const Duration(milliseconds: 500),
            ),

        SizedBox(height: 6.h),

        Text(
              data.headline,
              textAlign: isDesktop ? TextAlign.left : TextAlign.center,
              style: (isDesktop ? AppTextStyles.display() : AppTextStyles.h1())
                  .copyWith(fontSize: isDesktop ? 64.sp : 40.sp),
            )
            .animate()
            .fadeIn(
              delay: const Duration(milliseconds: 100),
              duration: const Duration(milliseconds: 500),
            )
            .slideY(
              begin: 0.2,
              end: 0,
              delay: const Duration(milliseconds: 100),
              duration: const Duration(milliseconds: 500),
            ),

        SizedBox(height: 10.h),

        Text(
          data.subHeadline,
          textAlign: isDesktop ? TextAlign.left : TextAlign.center,
          style: AppTextStyles.h3(color: AppColors.primary),
        ).animate().fadeIn(
          delay: const Duration(milliseconds: 200),
          duration: const Duration(milliseconds: 500),
        ),

        SizedBox(height: 20.h),

        ConstrainedBox(
          constraints: BoxConstraints(maxWidth: isDesktop ? 480.w : 520.w),
          child:
              Text(
                data.description,
                textAlign: isDesktop ? TextAlign.left : TextAlign.center,
                style: AppTextStyles.body(),
              ).animate().fadeIn(
                delay: const Duration(milliseconds: 300),
                duration: const Duration(milliseconds: 500),
              ),
        ),

        SizedBox(height: 32.h),

        Wrap(
          alignment: isDesktop ? WrapAlignment.start : WrapAlignment.center,
          spacing: 16.w,
          runSpacing: 12.h,
          children: [
            _PrimaryButton(
              label: data.primaryButtonText,
              onTap: () {
                if (data.primaryButtonRoute.isNotEmpty)
                  Get.toNamed(data.primaryButtonRoute);
              },
            ),
            _SecondaryButton(
              label: data.secondaryButtonText,
              icon: Icons.north_east_rounded,
              onTap: () {
                if (data.secondaryButtonRoute.isNotEmpty)
                  Get.toNamed(data.secondaryButtonRoute);
              },
            ),
          ],
        ).animate().fadeIn(
          delay: const Duration(milliseconds: 400),
          duration: const Duration(milliseconds: 500),
        ),
      ],
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 48.h,
          padding: EdgeInsets.symmetric(horizontal: 24.w),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            label,
            style: AppTextStyles.bodyMedium(color: AppColors.textOnPrimary)
                .copyWith(fontSize: 15.sp),
          ),
        ),
      ),
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _SecondaryButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 48.h,
          padding: EdgeInsets.symmetric(horizontal: 22.w),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.transparent,
            border: Border.all(color: AppColors.border),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: AppTextStyles.bodyMedium(color: AppColors.textPrimary)
                    .copyWith(fontSize: 15.sp),
              ),
              SizedBox(width: 8.w),
              Icon(icon, size: 16.sp, color: AppColors.textPrimary),
            ],
          ),
        ),
      ),
    );
  }
}

/// Portrait. Renders the Cloudinary photo once `homeContent.heroImageUrl`
/// is set from the admin panel; shows a placeholder icon until then.
class _HeroPortrait extends StatelessWidget {
  final String imageUrl;
  const _HeroPortrait({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    final hasImage = imageUrl.isNotEmpty;

    return AspectRatio(
      aspectRatio: 4 / 5,
      child:
          Container(
                decoration: BoxDecoration(
                  color: AppColors.surfaceSoft,
                  borderRadius: BorderRadius.circular(28.r),
                  border: Border.all(color: AppColors.border),
                  boxShadow: AppColors.featureShadow,
                ),
                alignment: Alignment.center,
                clipBehavior: Clip.antiAlias,
                child: hasImage
                    ? CachedNetworkImage(
                        imageUrl: imageUrl,
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                        placeholder: (_, __) => Icon(
                          Icons.person_outline_rounded,
                          size: 96.sp,
                          color: AppColors.primary.withValues(alpha: 0.3),
                        ),
                        errorWidget: (_, __, ___) => Icon(
                          Icons.person_outline_rounded,
                          size: 96.sp,
                          color: AppColors.primary.withValues(alpha: 0.3),
                        ),
                      )
                    : Icon(
                        Icons.person_outline_rounded,
                        size: 96.sp,
                        color: AppColors.primary.withValues(alpha: 0.3),
                      ),
              )
              .animate()
              .fadeIn(duration: const Duration(milliseconds: 600))
              .scale(
                begin: const Offset(0.96, 0.96),
                end: const Offset(1, 1),
                duration: const Duration(milliseconds: 600),
                curve: Curves.easeOutCubic,
              ),
    );
  }
}

class _HeroStatsRow extends StatelessWidget {
  final List<HomeStatModel> stats;
  const _HeroStatsRow({required this.stats});

  @override
  Widget build(BuildContext context) {
    final isDesktop = MediaQuery.of(context).size.width >= 1200;

    return Container(
      padding: EdgeInsets.symmetric(
        vertical: isDesktop ? 28.h : 20.h,
        horizontal: 12.w,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Wrap(
        alignment: WrapAlignment.spaceEvenly,
        runSpacing: 20.h,
        children: [
          for (final stat in stats)
            SizedBox(
              width: isDesktop ? null : 140.w,
              child: Column(
                children: [
                  Text(
                    stat.value,
                    style: AppTextStyles.statNumber(color: AppColors.primary),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    stat.label,
                    textAlign: TextAlign.center,
                    style: AppTextStyles.small(),
                  ),
                ],
              ),
            ),
        ],
      ),
    ).animate().fadeIn(
      delay: const Duration(milliseconds: 500),
      duration: const Duration(milliseconds: 500),
    );
  }
}
